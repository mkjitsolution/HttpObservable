import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { throwError , Observable } from 'rxjs'
import { catchError } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class AccountsServiceService {

  private endpoint = "/assets/data/accounts-json1.json";

  constructor(private http:HttpClient) { }

  getAllAccountsFromServer():Observable<AccountsServiceService[]>
  { // this.http.get(endpoint);
    return this.http.get<AccountsServiceService[]>(this.endpoint)
      .pipe(catchError(this.exceptionHandler));
  }

  exceptionHandler(error:HttpErrorResponse)
  {
    return throwError(error.message || "Server Error!! Contact to Customer Care");
  
  }

  getAllAccounts()
  {
    return [
      {id:101,name:"Sandeep",balance:3000},
      {id:102,name:"Ramesh",balance:4000},
      {id:103,name:"Gaurav",balance:6000}
    ];
  }
}



