import { Component, OnInit } from '@angular/core';
import { AccountsServiceService } from '../accounts-service.service';
@Component({
  selector: 'app-accounts-http',
  templateUrl: './accounts-http.component.html',
  styleUrls: ['./accounts-http.component.css']
})
export class AccountsHttpComponent implements OnInit {
  accounts = [];
  errorMsg;
  private __accountsServiceService: AccountsServiceService;
  constructor(__accountsServiceService:AccountsServiceService) {
    this.__accountsServiceService = __accountsServiceService;
   }
  ngOnInit() {
    this.__accountsServiceService.getAllAccountsFromServer()
      .subscribe(data=>this.accounts = data,
                error=>this.errorMsg = error);
      console.log(" ----->>> Http Component -> "+this.accounts.length);
  }
}
